#include "CATBASEUnknown.h"
#include<iostream>
using namespace std;

CATBASEUnknown::CATBASEUnknown() {

	_refCount = 0;
}
CATBASEUnknown:: ~CATBASEUnknown() {

}
void  CATBASEUnknown::adddref() {
	_refCount++;
	cout << "ref count is" << _refCount << endl;

}
void CATBASEUnknown::releaseref() {
	_refCount--;
	cout << "release count  " << _refCount << endl;
	if (_refCount == 0)
		delete this;

	
}