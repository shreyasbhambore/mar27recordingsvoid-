#pragma once
#include "IUnkownclass.h"
#include "CATBASEUnknown.h"
#include "ICalculator.h"
class IMobile:public CATBASEUnknown
{
public:
	IMobile();
	~IMobile();
	virtual void makecall() = 0;
	virtual void recivecall() = 0;
	virtual void queryinterface(int i, IUnkownclass**) = 0;

};

