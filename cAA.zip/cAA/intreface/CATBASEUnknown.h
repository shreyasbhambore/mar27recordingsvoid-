#pragma once
#include"IUnkownclass.h"
class CATBASEUnknown:public IUnkownclass
{
	int _refCount;
public:
	CATBASEUnknown();
	~CATBASEUnknown();
	virtual void adddref();
	virtual void releaseref();
	
};

