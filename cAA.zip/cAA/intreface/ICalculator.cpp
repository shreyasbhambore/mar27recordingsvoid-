#include "ICalculator.h"
ICalculator::ICalculator(){

}