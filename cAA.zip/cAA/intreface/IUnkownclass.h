#pragma once

class IUnkownclass
{

public:

	IUnkownclass();
	~IUnkownclass();
	virtual void adddref() = 0;
	virtual void releaseref() = 0;
	virtual void queryinterface(int i, IUnkownclass**) = 0;




};

