#pragma once
#include "IUnkownClass.h"
#include "CATBaseUnknown.h"
class ICalculator
{
public :
	ICalculator();
	virtual void add() = 0;
	virtual void sub() = 0;

};

