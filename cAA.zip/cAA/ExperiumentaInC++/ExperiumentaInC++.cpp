#include <iostream>
using namespace std;

class A {
    int a;
public:
    A() { a = 9; }

    virtual void show()
    {
        cout << "Hello form A \n";
    }
};

class B : public A {
   
public:  
    int b;
    void show()
    {
        cout << "Hello form B \n";
    }
};

class C :   public A {
public:
    void show()
    {
        cout << "Hello form C \n";
    }
};

class D : public B, public C {
public:
    void show()
    {
        cout << "Hello form D \n";
    }
};

int main()
{
    B objB;
    //objB.show(); // compile time resolved

    A* pObjA = new B(); // vptr, a, b
    pObjA->show(); 
    //cout << "value of int" << *(pObjA + 1) << endl;
    // cout << "size of: " << sizeof(*pObjA) << endl;


   /* animal[] = { new dog, new cat, new horse }
        for
            animal* an->noise(); // bark, meow, .... */
        // animal->type ...

}